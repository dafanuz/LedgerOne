import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    server: {
      port: 3000,
      host: '0.0.0.0',
      allowedHosts: ['hypatia-unbeaded-edison.ngrok-free.dev'],
    },
    plugins: [react(), VitePWA({
      // add this to cache all the imports
      workbox: {
        globPatterns: ["**/*"],
      },
      // add this to cache all the
      // static assets in the public folder
      includeAssets: [
        "**/*",
      ],
      manifest: {
        "name": "LedgerOne Bookkeeping",
        "short_name": "LedgerOne",
        "description": "Aplikasi pencatatan keuangan berbasis standar akuntansi profesional  (Double-Entry) namun dikemas dengan antarmuka yang ramah bagi pemula.",
        "scope": "/",
        "start_url": "/",
        "theme_color": "#2563eb",
        "background_color": "#ffffff",
        "display": "standalone",
        "icons": [
          {
            "src": "/favicon.ico",
            "sizes": "64x64 32x32 24x24 16x16",
            "type": "image/x-icon"
          },
          {
            "src": "/icons/windows11/SmallTile.scale-100.png",
            "sizes": "71x71"
          },
          {
            "src": "/icons/windows11/SmallTile.scale-125.png",
            "sizes": "89x89"
          },
          {
            "src": "/icons/windows11/SmallTile.scale-150.png",
            "sizes": "107x107"
          },
          {
            "src": "/icons/windows11/SmallTile.scale-200.png",
            "sizes": "142x142"
          },
          {
            "src": "/icons/windows11/SmallTile.scale-400.png",
            "sizes": "284x284"
          },
          {
            "src": "/icons/windows11/Square150x150Logo.scale-100.png",
            "sizes": "150x150"
          },
          {
            "src": "/icons/windows11/Square150x150Logo.scale-125.png",
            "sizes": "188x188"
          },
          {
            "src": "/icons/windows11/Square150x150Logo.scale-150.png",
            "sizes": "225x225"
          },
          {
            "src": "/icons/windows11/Square150x150Logo.scale-200.png",
            "sizes": "300x300"
          },
          {
            "src": "/icons/windows11/Square150x150Logo.scale-400.png",
            "sizes": "600x600"
          },
          {
            "src": "/icons/windows11/Wide310x150Logo.scale-100.png",
            "sizes": "310x150"
          },
          {
            "src": "/icons/windows11/Wide310x150Logo.scale-125.png",
            "sizes": "388x188"
          },
          {
            "src": "/icons/windows11/Wide310x150Logo.scale-150.png",
            "sizes": "465x225"
          },
          {
            "src": "/icons/windows11/Wide310x150Logo.scale-200.png",
            "sizes": "620x300"
          },
          {
            "src": "/icons/windows11/Wide310x150Logo.scale-400.png",
            "sizes": "1240x600"
          },
          {
            "src": "/icons/windows11/LargeTile.scale-100.png",
            "sizes": "310x310"
          },
          {
            "src": "/icons/windows11/LargeTile.scale-125.png",
            "sizes": "388x388"
          },
          {
            "src": "/icons/windows11/LargeTile.scale-150.png",
            "sizes": "465x465"
          },
          {
            "src": "/icons/windows11/LargeTile.scale-200.png",
            "sizes": "620x620"
          },
          {
            "src": "/icons/windows11/LargeTile.scale-400.png",
            "sizes": "1240x1240"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.scale-100.png",
            "sizes": "44x44"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.scale-125.png",
            "sizes": "55x55"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.scale-150.png",
            "sizes": "66x66"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.scale-200.png",
            "sizes": "88x88"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.scale-400.png",
            "sizes": "176x176"
          },
          {
            "src": "/icons/windows11/StoreLogo.scale-100.png",
            "sizes": "50x50"
          },
          {
            "src": "/icons/windows11/StoreLogo.scale-125.png",
            "sizes": "63x63"
          },
          {
            "src": "/icons/windows11/StoreLogo.scale-150.png",
            "sizes": "75x75"
          },
          {
            "src": "/icons/windows11/StoreLogo.scale-200.png",
            "sizes": "100x100"
          },
          {
            "src": "/icons/windows11/StoreLogo.scale-400.png",
            "sizes": "200x200"
          },
          {
            "src": "/icons/windows11/SplashScreen.scale-100.png",
            "sizes": "620x300"
          },
          {
            "src": "/icons/windows11/SplashScreen.scale-125.png",
            "sizes": "775x375"
          },
          {
            "src": "/icons/windows11/SplashScreen.scale-150.png",
            "sizes": "930x450"
          },
          {
            "src": "/icons/windows11/SplashScreen.scale-200.png",
            "sizes": "1240x600"
          },
          {
            "src": "/icons/windows11/SplashScreen.scale-400.png",
            "sizes": "2480x1200"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-16.png",
            "sizes": "16x16"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-20.png",
            "sizes": "20x20"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-24.png",
            "sizes": "24x24"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-30.png",
            "sizes": "30x30"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-32.png",
            "sizes": "32x32"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-36.png",
            "sizes": "36x36"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-40.png",
            "sizes": "40x40"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-44.png",
            "sizes": "44x44"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-48.png",
            "sizes": "48x48"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-60.png",
            "sizes": "60x60"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-64.png",
            "sizes": "64x64"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-72.png",
            "sizes": "72x72"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-80.png",
            "sizes": "80x80"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-96.png",
            "sizes": "96x96"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.targetsize-256.png",
            "sizes": "256x256"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-16.png",
            "sizes": "16x16"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-20.png",
            "sizes": "20x20"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-24.png",
            "sizes": "24x24"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-30.png",
            "sizes": "30x30"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-32.png",
            "sizes": "32x32"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-36.png",
            "sizes": "36x36"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-40.png",
            "sizes": "40x40"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-44.png",
            "sizes": "44x44"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-48.png",
            "sizes": "48x48"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-60.png",
            "sizes": "60x60"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-64.png",
            "sizes": "64x64"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-72.png",
            "sizes": "72x72"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-80.png",
            "sizes": "80x80"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-96.png",
            "sizes": "96x96"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-unplated_targetsize-256.png",
            "sizes": "256x256"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-16.png",
            "sizes": "16x16"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-20.png",
            "sizes": "20x20"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-24.png",
            "sizes": "24x24"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-30.png",
            "sizes": "30x30"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-32.png",
            "sizes": "32x32"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-36.png",
            "sizes": "36x36"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-40.png",
            "sizes": "40x40"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-44.png",
            "sizes": "44x44"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-48.png",
            "sizes": "48x48"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-60.png",
            "sizes": "60x60"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-64.png",
            "sizes": "64x64"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-72.png",
            "sizes": "72x72"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-80.png",
            "sizes": "80x80"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-96.png",
            "sizes": "96x96"
          },
          {
            "src": "/icons/windows11/Square44x44Logo.altform-lightunplated_targetsize-256.png",
            "sizes": "256x256"
          },
          {
            "src": "/icons/android/android-launchericon-512-512.png",
            "sizes": "512x512"
          },
          {
            "src": "/icons/android/android-launchericon-192-192.png",
            "sizes": "192x192"
          },
          {
            "src": "/icons/android/android-launchericon-144-144.png",
            "sizes": "144x144"
          },
          {
            "src": "/icons/android/android-launchericon-96-96.png",
            "sizes": "96x96"
          },
          {
            "src": "/icons/android/android-launchericon-72-72.png",
            "sizes": "72x72"
          },
          {
            "src": "/icons/android/android-launchericon-48-48.png",
            "sizes": "48x48"
          },
          {
            "src": "/icons/ios/16.png",
            "sizes": "16x16"
          },
          {
            "src": "/icons/ios/20.png",
            "sizes": "20x20"
          },
          {
            "src": "/icons/ios/29.png",
            "sizes": "29x29"
          },
          {
            "src": "/icons/ios/32.png",
            "sizes": "32x32"
          },
          {
            "src": "/icons/ios/40.png",
            "sizes": "40x40"
          },
          {
            "src": "/icons/ios/50.png",
            "sizes": "50x50"
          },
          {
            "src": "/icons/ios/57.png",
            "sizes": "57x57"
          },
          {
            "src": "/icons/ios/58.png",
            "sizes": "58x58"
          },
          {
            "src": "/icons/ios/60.png",
            "sizes": "60x60"
          },
          {
            "src": "/icons/ios/64.png",
            "sizes": "64x64"
          },
          {
            "src": "/icons/ios/72.png",
            "sizes": "72x72"
          },
          {
            "src": "/icons/ios/76.png",
            "sizes": "76x76"
          },
          {
            "src": "/icons/ios/80.png",
            "sizes": "80x80"
          },
          {
            "src": "/icons/ios/87.png",
            "sizes": "87x87"
          },
          {
            "src": "/icons/ios/100.png",
            "sizes": "100x100"
          },
          {
            "src": "/icons/ios/114.png",
            "sizes": "114x114"
          },
          {
            "src": "/icons/ios/120.png",
            "sizes": "120x120"
          },
          {
            "src": "/icons/ios/128.png",
            "sizes": "128x128"
          },
          {
            "src": "/icons/ios/144.png",
            "sizes": "144x144"
          },
          {
            "src": "/icons/ios/152.png",
            "sizes": "152x152"
          },
          {
            "src": "/icons/ios/167.png",
            "sizes": "167x167"
          },
          {
            "src": "/icons/ios/180.png",
            "sizes": "180x180"
          },
          {
            "src": "/icons/ios/192.png",
            "sizes": "192x192"
          },
          {
            "src": "/icons/ios/256.png",
            "sizes": "256x256"
          },
          {
            "src": "/icons/ios/512.png",
            "sizes": "512x512"
          },
          {
            "src": "/icons/ios/1024.png",
            "sizes": "1024x1024"
          }
        ],
      },
    })],
    define: {
      'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      'process.env.VITE_SUPABASE_URL': JSON.stringify(env.VITE_SUPABASE_URL),
      'process.env.VITE_SUPABASE_PUBLISHABLE_KEY': JSON.stringify(env.VITE_SUPABASE_PUBLISHABLE_KEY),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      }
    },
    build: {
      chunkSizeWarningLimit: 1000,
      rollupOptions: {
        output: {
          manualChunks: {
            'vendor': ['react', 'react-dom', 'react-router-dom'],
            'supabase': ['@supabase/supabase-js'],
            'genai': ['@google/genai'],
            'date': ['date-fns'],
            'ui': ['lucide-react'],
          },
        },
      },
    },
  };
});

