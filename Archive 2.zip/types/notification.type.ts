export interface NotificationPayload {
  title: string;
  body: string;
}

export interface SavingsRateResult {
  savings_rate: number;
}
